#ifndef __MYSORT_H__
#define __MYSORT_H__

void sortBySystemFunction(char *fileName, unsigned int recordQuantity, unsigned int recordLength);
void sortByLibraryFunction(char *fileName, unsigned int recordQuantity, unsigned int recordLength);

#endif
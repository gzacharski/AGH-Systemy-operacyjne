#ifndef __MYLOG_H__
#define __MYLOG_H__

void logInfo(int argc, char* argv[]);
void logError();
//void logDuration(struct tms *st_cpu, struct tms *en_cpu, clock_t st_time, clock_t en_time);

#endif
#ifndef __MYGENERATE_H__
#define __MYGENERATE_H__

void generate(char *fileName, unsigned int recordQuantity, unsigned int recordLength);
void readFile(char *fileName, unsigned int recordQuantity, unsigned int recordLength);

#endif
# Zadania - zestaw 1.
## Zarządzanie pamięcią, biblioteki, pomiar czasu 
### Zadanie 1.  Kompilator, optymalizacja, pomiar czasu (50%)
Przygotuj zestaw czterech programów, a następnie dokonaj pomiarów czasów ich działania przy różnych flagach optymalizacyjnych kompilatora gcc.

Przygotuj raport z tymi wynikami oraz komentarzami wyników.

### Zadanie 2. Program korzystający z biblioteki (50%)
Wyodrębnij prostą bibliotekę z jednego z zadań z zestawu pierwszego. Stwórz programy wykonywalne z biblioteką statyczną, współdzieloną oraz łądowaną dynamicznie.

Dokonaj pomiarów czasów działania programów stworzonymi przy pomocy każdej z powyższych metod. Przygotuj raport z wynikami i komentarzami.
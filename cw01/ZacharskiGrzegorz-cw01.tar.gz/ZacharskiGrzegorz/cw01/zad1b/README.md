# Zadanie 1.  Kompilator, optymalizacja, pomiar czasu
## Program 2 z 4
Program tworzy 2 tablice char o rozmierze SIZEi wpisuje do kazdej komorki losowy znak od a-z Nastepnie tworzy 3 tablice i scala dwie tablice w jeden napis.
# Zadanie 1.  Kompilator, optymalizacja, pomiar czasu
## Program 4 z 4
Program wypisuje liczby doskonale w zakresie NUMBER lub w podanym przez użytkownika. Liczba doskonala to taka liczba, ktorej suma dzielnikow, oprocz niej samej, jest rowna rozpatrywanej liczbie.
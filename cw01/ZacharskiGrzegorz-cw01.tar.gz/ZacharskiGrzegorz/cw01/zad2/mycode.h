#ifndef __MYCODE_H__
#define __MYCODE_H__

int isPerfectNumber(int number); 

#endif
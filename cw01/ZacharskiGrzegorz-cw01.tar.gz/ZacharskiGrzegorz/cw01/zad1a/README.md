# Zadanie 1.  Kompilator, optymalizacja, pomiar czasu
## Program 1 z 4
Program tworzy zmienna sum, a nastepnie wykonuje operacje na niej dodajac lub odejmujac kolejne liczby.
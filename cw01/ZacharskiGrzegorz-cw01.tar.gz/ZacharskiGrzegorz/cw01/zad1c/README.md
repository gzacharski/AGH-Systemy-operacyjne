# Zadanie 1.  Kompilator, optymalizacja, pomiar czasu
## Program 3 z 4
Program tworzy tablice o rozmiarze SIZE i wpisuje do niej kolejne liczby ciagu Fibonacciego, uzywajac funkcji rekurencyjnej (zabieg celowy).